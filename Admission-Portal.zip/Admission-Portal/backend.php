<?php
session_start();
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "admission_portal";

$con = new mysqli($hostname, $username, $password, $dbname);

$_SESSION['a']=1;

$email = $_GET['email'];
$value = $_GET['value'];
$transfer = $_GET['page'];
$a = 'admin';
$ac = 'accept';
$w = 'wait';
$r = 'reject';
if($value==1)
	$status = "Accepted";
if($value==2)
	$status = "Waiting";
if($value==3)
	$status = "Rejected";

$rq = "UPDATE student SET Status='$status' where Student_Email=$email";
$ans = $con->query($rq);
echo $transfer." ".$a." ".$ac." ".$w." ".$r;

if($transfer == $a)
header("location:a_dash.php");
else if($transfer == $ac)
header("location:accept.php");
else if($transfer==$r)
header("location:reject.php");
else
header("location:wait.php");
?>