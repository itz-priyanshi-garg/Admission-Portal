<?php 

$First_Name = $_POST['First_Name'];
$Last_Name = $_POST['Last_Name'];
$Birthday_day = $_POST['Birthday_day'];
$Birthday_Month = $_POST['Birthday_Month'];
$Birthday_Year = $_POST['Birthday_Year'];
$Student_Email = $_POST['Student_Email'];
$Student_Mobile = $_POST['Student_Mobile'];
$Gender = $_POST['Gender'];
$Mothername = $_POST['Mothername'];
$Mother_Email = $_POST['Mother_Email'];
$Mother_Mobile = $_POST['Mother_Mobile'];
$Fathername = $_POST['Fathername'];
$Father_Email = $_POST['Father_Email'];
$Father_Mobile = $_POST['Father_Mobile'];
$Address = $_POST['Address'];
$City = $_POST['City'];
$Pin_Code = $_POST['Pin_Code'];
$State = $_POST['State'];
$Country = $_POST['Country'];
$ClassX_Board = $_POST['ClassX_Board'];
$ClassX_Percentage = $_POST['ClassX_Percentage'];
$ClassX_YrOfPassing = $_POST['ClassX_YrOfPassing'];
$ClassXII_Board = $_POST['ClassXII_Board'];
$ClassXII_Percentage = $_POST['ClassXII_Percentage'];
$ClassXII_YrOfPassing = $_POST['ClassXII_YrOfPassing'];
$Upsee_Rank = $_POST['Upsee_Rank'];
$Course = $_POST['Course'];

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "admission_portal";

$con = new mysqli($hostname, $username, $password, $dbname);

$status = "It will be updated soon";
$sq = "insert into student values('$First_Name', '$Last_Name', $Birthday_day, '$Birthday_Month', $Birthday_Year, '$Student_Email',
      $Student_Mobile, '$Gender', '$Mothername', '$Mother_Email', $Mother_Mobile, '$Fathername', '$Father_Email', $Father_Mobile, 
	  '$Address', '$City', $Pin_Code, '$State', '$Country', '$ClassX_Board', $ClassX_Percentage, $ClassX_YrOfPassing,
	  '$ClassXII_Board', $ClassXII_Percentage, $ClassXII_YrOfPassing, $Upsee_Rank, '$Course', '$status')";

$lq = "insert into login values('$Student_Email', '$Student_Mobile', md5($Student_Mobile))";
$abc = $First_Name." ".$Last_Name;



if($con->query($sq))
	echo "row inserted";
else
	echo "row not inserted ".$con->error;

if($con->query($lq))
	echo "row inserted login";
else
	echo "row not inserted ".$con->error;

header("location:admlogin.php");

?>

