<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="css/b.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!-- Bootstrap JS and other JS files-->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script> 
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
</head>
<body>

<?php 
session_start();
$Student_Email = $_POST['username'];
$Password = $_POST['password'];
	
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "admission_portal";

$con = new mysqli($hostname, $username, $password, $dbname);

if($Student_Email=="admin" && $Password=="0000")
{	
	header("location:a_dash.php");
	die;
}

$sq = "select * from login where email='$Student_Email' and password='$Password'";
$rs = $con->query($sq);

if(!($rs->num_rows))
{   
    $msg="Please Enter correct UserName and Password!!!!";
	$_SESSION['err']=$msg;
	header("location:admlogin.php");
}
$ro = "select * from student where Student_Email='$Student_Email'";
$row = $con->query($ro);
$rs = $row->fetch_array();
?>

<!-- Page Header start-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12 text-center"><h1>ABES Engineering College</h1></div>
</div>
<!--start navbar-->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
<a href= "#" class="navbar-brand"><img src="images/abes.png" height="50" width="150"></a>
  <a href="#" class="navbar-brand text-white"><b>ABESEC</b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
  <a href="#" class="navbar-brand text-Primary">Welcome, <?php echo " ".$rs[0];?></a>
  
  <button class="navbar-toggler" data-toggle="collapse" data-target="#m">
  <span class="navbar-toggler-icon"></span>
  
  </button>
  <div id="m" class="collapse navbar-collapse">
  <ul class="navbar-nav ml-auto">
    
	 </li>
	 <li class="nav-item"><a href="c_p.php?value='<?php echo $rs[5];?>'"  class="nav-link">Change Password&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
	 <li class="nav-item"><a href="logout.php" class="nav-link">Logout&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
  </ul>
  </div>
</nav>
<br><br>


<div><h2 style="color:#204987; height:30px ; text-align:center">Student Details</h2></div><br>
<div class="row">
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>First Name : </b><?php echo " ".$rs[0];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Last Name : </b><?php echo " ".$rs[1];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Date of Birth : </b><?php echo " ".$rs[2]." / ".$rs[3]." / ".$rs[4];?></h4></div>
 </div>
 <br>
 <div class="row">
 <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Contact No : </b><?php echo " ".$rs[6];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Email : </b><?php echo " ".$rs[5];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Gender : </b><?php echo " ".$rs[7];?></h4></div>
</div>
<br><br><br>

<div><h2 style="color:#204987; height:30px ; text-align:center">Parent Details</h2></div><br>

<div class="row">
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Father Name : </b><?php echo " ".$rs[11];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Father Email : </b><?php echo " ".$rs[12];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Father Contact No : </b><?php echo " ".$rs[13];?></h4></div>
 </div>
 <br>
 <div class="row">
 <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Mother Name : </b><?php echo " ".$rs[8];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Mother Email : </b><?php echo " ".$rs[9];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Mother Contact No : </b><?php echo " ".$rs[10];?></h4></div>
</div>
<br><br><br>

<div><h2 style="color:#204987; height:30px ; text-align:center">Academic Details</h2></div><br>
<div class="row">
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>10<sup>th</sup> Board : </b><?php echo " ".$rs[19];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>10<sup>th</sup> Aggregate : </b><?php echo " ".$rs[20];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>10<sup>th</sup> Passing Year : </b><?php echo " ".$rs[21];?></h4></div>
 </div>
 <br>
 <div class="row">
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>12<sup>th</sup> Board : </b><?php echo " ".$rs[22];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>12<sup>th</sup> Aggregate : </b></b><?php echo " ".$rs[23];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>12<sup>th</sup> Passing Year : </b><?php echo " ".$rs[24];?></h4></div>
</div>
<br>
<div class="row">
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>UPSEE rank : </b><?php echo " ".$rs[25];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Course Applied : </b><?php echo " ".$rs[26];?></h4></div>
	<div class="col-sm-4" style="background-color:#DEF8DE; height:40px"><h4 style="text-align:center"></h4></div>
</div>

<br><br><br>
<div><h2 style="color:#204987; height:30px ; text-align:center">Residence Details</h2></div><br>
<div class="row">
	<div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Address: </b><?php echo " ".$rs[14];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>City : </b><?php echo " ".$rs[15];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Pin Code : </b><?php echo " ".$rs[16];?></h4></div>
</div>
<br>
<div class="row">
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>State : </b><?php echo " ".$rs[17];?></h4></div>
    <div class="col-sm-4" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Country : </b><?php echo " ".$rs[18];?></h4></div>
	<div class="col-sm-4" style="background-color:#DEF8DE; height:40px"><h4 style="text-align:center"></h4></div>
</div>

<br><br><br>
<div><h2 style="color:#204987; height:30px ; text-align:center">Application Status</h2></div><br>
	<div class="row">
    <div class="col-sm-6" style="background-color:#DEF8DE;"><h4 style="text-align:center"><b>Status : </b><?php echo " ".$rs[27]; ?></h4></div>
	
		<div class="col-sm-6" style="background-color:#DEF8DE; height:40px"><h4 style="text-align:center"></h4></div>

</div>
<br>

</body>
</html>