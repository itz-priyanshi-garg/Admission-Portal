<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="css/b.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!-- Bootstrap JS and other JS files-->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script> 
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
</head>
<body>

<!-- Page Header start-->
<div class="container-fluid">
<div class="row">
<div class="col-md-12 text-center"><h1>ABES Engineering College</h1></div>
</div>
<!--start navbar-->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
<a href= "#" class="navbar-brand"><img src="images/abes.png" height="50" width="150"></a>
  <a href="#" class="navbar-brand text-white"><b>ABESEC</b></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
  <a href="#" class="navbar-brand text-Primary">Welcome, Admin</a>
  
  <button class="navbar-toggler" data-toggle="collapse" data-target="#m">
  <span class="navbar-toggler-icon"></span>
  
  </button>
  <div id="m" class="collapse navbar-collapse">
  <ul class="navbar-nav ml-auto">
    
	 <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" data-toggle="dropdown">Students</a>
	 
	 <!-- desinging dropdown start-->
	  <ul class="dropdown-menu">
	      <li><a href="accept.php" class="dropdown-item" >Accepted Students</a> </li>
		   <li><a href="wait.php" class="dropdown-item">Waiting Students</a> </li>
		    <li><a href="reject.php" class="dropdown-item">Rejected Students</a> </li>	 
	  </ul>	 
	 <!-- dropdown end-->
	 
	 
	 </li>
	 <li class="nav-item"><a class="nav-link">Change Password&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
	 <li class="nav-item"><a href="logout.php" class="nav-link">Logout&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
  </ul>
  </div>
</nav>
<br>
</div>
<div><h1 style="color:#204987; height:30px ; text-align:center"><b>Students Details</b></h1></div><hr style="visibility:hidden"></hr>
<table class="table table-striped" class="table-responsive">
	<td><h4><b>Sr No</b></h4></td>
    <td><h4><b>Name </b></h4></td>
    <td><h4><b>Email </b></h4></td>
	<td><h4><b>10<sup>th</sup> Board </b></td>
	<td><h4><b>10<sup>th</sup> % </b></h4></td>
	<td><h4><b>12<sup>th</sup> Board </b></td>
	<td><h4><b>12<sup>th</sup> %</b></h4></td>
	<td><h4><b>UPSEE rank </b></h4></td>
	<td><h4><b>Course</b></h4></td>
	<td><h4><b>Status </b></h4></td>
<?php
session_start();

if(isset($_SESSION['a']))
{	
require 'alert.php';	
session_destroy();
}

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "admission_portal";

$con = new mysqli($hostname, $username, $password, $dbname);
$sq = "select * from student where Status = 'Waiting'";
$ro = $con->query($sq);
$i=1;
while($row = $ro->fetch_array())
{
	$name = $row[0]." ".$row[1];
?>
	<tr>
	<td><b><?php echo $i."."?></b></td>
    <td><?php echo $name?></td>
	<td><?php echo $row[5]?></td>
    <td><?php echo $row[19]?></td>
	<td><?php echo $row[20]?></td>
	<td><?php echo $row[22]?></td>
	<td><?php echo $row[23]?></td>
	<td><?php echo $row[25]?></td>
	<td><?php echo $row[26]?></td>
	
	<td>
		<a class="btn btn-success" href="backend.php?value=1&email='<?php echo $row[5]?>'&page=wait" role="button">Accepted</a>
		<a class="btn btn-danger" href="backend.php?value=3&email='<?php echo $row[5]?>'&page=wait" role="button">Rejected</a>
	</td>
	</tr>
<?php
$i = $i+1;
}
?>
</table>
</body>
</html>



