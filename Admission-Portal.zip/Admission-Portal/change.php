<?php
session_start();
	$email = $_POST['email'];
	$op =  $_POST['inputPasswordOld'];
	$np = $_POST['inputPasswordNew'];
	$cnp = $_POST['inputPasswordNewVerify'];
	
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "admission_portal";

$con = new mysqli($hostname, $username, $password, $dbname);

$rq = "select * from login where email =$email";
$ans = $con->query($rq);
$row = $ans->fetch_array();

if($op == $row[1])
{
	if($np == $cnp)
	{echo $con->error."55555555555555555555555555";
		$sq = "UPDATE login set password = $np and enc_password = md5('$np') where email = $email";
		
		$ans = $con->query($sq);
		
		$_SESSION['err'] = "Password Changed Successfully!!";
	}
	else
	{
		$_SESSION['err'] = "New password and Confirm new password don't match!!";
	}
}
else
{
		$_SESSION['err'] = "Old password is incorrect!!";
}
echo $_SESSION['err'];
header("location:c_p.php");
?>