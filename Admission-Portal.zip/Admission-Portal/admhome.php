<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">

    <title>Admission</title>
    <style>
       
    
        $primary-light-blue: #8DB9ED;
        $primary-line-color: #ccc;
    
        * {
          box-sizing: border-box
        }
    
        html,
        body {
          height: 100%
        }
    
        body {
          font: 11px "Open Sans", sans-serif;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
          margin: auto;
          display: flex;
          flex-flow: column nowrap;
  
        }
    
        ul {
          list-style: none
        }
    
        a {
          text-decoration: none
        }
    
    
    
        .flex-rw {
          display: flex;
          flex-flow: row wrap;
        }
        main {
          flex: 1 1 auto; 
          display: flex;
          align-items: center;
          justify-content: center;
          font: 10em "Oswald", sans-serif;
          color: rgb(155, 155, 155);
          line-height: 1
        }
    
        footer {
          background: rgb(55, 55, 55);
          margin-top: auto;
          width: 100%
        }
    
        .footer-list-top {
          width: 33.333%
        }
    
        .footer-list-top>li {
          text-align: center;
          padding-bottom: 10px
        }
    
        .footer-list-header {
          padding: 10px 0 5px 0;
          color: #fff;
          font: 2.3vw "Oswald", sans-serif
        }
    
        .footer-list-anchor {
          font: 1.3em "Open Sans", sans-serif
        }
    
        .footer-social-section {
          width: 100%;
          align-items: center;
          justify-content: space-around;
          position: relative;
          margin-top: 5px;
        }
    
        .footer-social-section::after {
          content: "";
          position: absolute;
          z-index: 1;
          top: 50%;
          left: 10px;
          border-top: 1px solid $primary-line-color;
          width: calc(100% - 20px)
        }
    
        .footer-social-overlap {
          position: relative;
          z-index: 2;
          background: rgb(55, 55, 55);
          padding: 0 20px
        }
    
        .footer-social-connect {
          display: flex;
          align-items: center;
          font: 3.5em "Oswald", sans-serif;
          color: #fff
        }
    
        .footer-social-small {
          font-size: 0.6em;
          padding: 0px 20px
        }
    
        .footer-social-overlap>a {
          font-size: 3em
        }
    
        .footer-social-overlap>a:not(:first-child) {
          margin-left: 0.38em
        }
    
        .footer-bottom-section {
          width: 100%;
          padding: 10px;
          border-top: 1px solid $primary-line-color;
          margin-top: 10px
        }
    
        .footer-bottom-section>div:first-child {
          margin-right: auto
        }
    
        .footer-bottom-wrapper {
          font-size: 1.5em;
          color: #fff
        }
    
        .footer-address {
          display: inline;
          font-style: normal
        }
    
        @media only screen and (max-width: 768px) {
          .footer-list-header {
            font-size: 2em
          }
    
          .footer-list-anchor {
            font-size: 1.1em
          }
    
          .footer-social-connect {
            font-size: 2.5em
          }
    
          .footer-social-overlap>a {
            font-size: 2.24em
          }
    
          .footer-bottom-wrapper {
            font-size: 1.3em
          }
        }
    
        @media only screen and (max-width: 568px) {
          main {
            font-size: 5em
          }
    
          .footer-list-top {
            width: 100%
          }
    
          .footer-list-header {
            font-size: 3em;
          }
    
          .footer-list-anchor {
            font-size: 1.5em
          }
    
          .footer-social-section {
            justify-content: center
          }
    
          .footer-social-section::after {
            top: 25%
          }
    
          .footer-social-connect {
            margin-bottom: 10px;
            padding: 0 10px
          }
    
          .footer-social-overlap {
            display: flex;
            justify-content: center;
          }
    
          .footer-social-icons-wrapper {
            width: 100%;
            padding: 0
          }
    
          .footer-social-overlap>a:not(:first-child) {
            margin-left: 20px;
          }
    
          .footer-bottom-section {
            padding: 0 5px 10px 5px
          }
    
          .footer-bottom-wrapper {
            text-align: center;
            width: 100%;
            margin-top: 10px
          }
        }
    
        @media only screen and (max-width: 480px) {
          .footer-social-overlap>a {
            margin: auto
          }
    
          .footer-social-overlap>a:not(:first-child) {
            margin-left: 0;
          }
    
          .footer-bottom-rights {
            display: block
          }
        }
    
        @media only screen and (max-width: 320px) {
          .footer-list-header {
            font-size: 2.2em
          }
    
          .footer-list-anchor {
            font-size: 1.2em
          }
    
          .footer-social-connect {
            font-size: 2.4em
          }
    
          .footer-social-overlap>a {
            font-size: 2.24em
          }
    
          .footer-bottom-wrapper {
            font-size: 1.3em
          }
        }
      </style>
  </head>
  <body>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->

    <div>
        <div style="background-color:#204987; height:30px; margin-bottom:10px;"></div>
        <b><h1 style="color:#204987; height:50px ; text-align:center" >Online Admission Portal</h1></b>
        <div style="background-color:#204987; height:50px; margin-top:10px;">
           <a href="admlogin.php"> <button style="float: right;background-color: white; border-radius:8px;margin-right:2px;margin-top:5px;
            color:#204987;font-weight:bold;font-size: 15px;height:40px;">Official Login</button></a>
        </div>
    </div>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
          <h1 class="display-4" style="margin-bottom:20px;font-weight:bold;color:black;">Online Admission 2021-2022</h1>
          <span>
              <a href="refuter.php"><button  style="border-radius:8px;margin-right:2px;margin-top:10px;background-color:#204987;border:none;
              color:white;font-weight:bold;height:45px;width:90px;font-size: 15px;">Register</button></a>
              <a href="admlogin.php"><button style="border-radius:8px;margin-right:2px;margin-top:10px;background-color:#204987;border:none;
              color:white;font-weight:bold;height:45px;width:90px;font-size: 15px;">Login</button></a>
          </span>
        </div>
    </div><br><br>
    <div class="container">
        <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col" style="font-size: 15px;font-weight:bold;">Sr.No</th>
            <th scope="col" style="font-size: 15px;font-weight:bold;">Title</th>
            <th scope="col" style="font-size: 15px;font-weight:bold;">Date</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td style="font-size: 15px;">Online submission of Admission form - Start Date</td>
            <td style="font-size: 15px;">7th September</td>
          </tr>
          <tr>
            <th scope="row" style="font-size: 15px;">2</th>
            <td style="font-size: 15px;">Online submission of Admission form - End Date</td>
            <td style="font-size: 15px;">24th September </td>
          </tr>
          <tr>
            <th scope="row" style="font-size: 15px;">3</th>
            <td style="font-size: 15px;">Display of 1st Merit List</td>
            <td style="font-size: 15px;">1st October </td>
          </tr>
          <tr>
            <th scope="row" style="font-size: 15px;">4</th>
            <td style="font-size: 15px;">Display of 2nd Merit List</td>
            <td style="font-size: 15px;">11th October </td>
          </tr>
        </tbody>
      </table>
    </div>
      <br><br><br>
      <footer class="flex-rw">


        <section class="footer-social-section flex-rw" style="height:50px;">
          <span class="footer-social-overlap footer-social-connect">
             <span class="footer-social-small" style="font-size: 18px;">Copyright@ABC</span> 
          </span><br>
          <span class="footer-social-overlap footer-social-icons-wrapper">
            
            <a  class="generic-anchor" target="_blank" title="Facebook"
              itemprop="significantLink"><i class="fa fa-facebook" style="color: white;font-size:24px;"></i></a>
            <a class="generic-anchor" target="_blank" title="Twitter"
              itemprop="significantLink"><i class="fa fa-twitter" style="color: white;font-size:24px;"></i></a>
            <a class="generic-anchor" target="_blank" title="Instagram"
              itemprop="significantLink"><i class="fa fa-instagram" style="color: white;font-size:24px;"></i></a>
            <a class="generic-anchor" target="_blank"
              title="Youtube" itemprop="significantLink"><i class="fa fa-youtube" style="color: white;font-size:24px;"></i></a>
            <a  class="generic-anchor" target="_blank" title="Google Plus"
              itemprop="significantLink"><i class="fa fa-google-plus" style="color: white;font-size:24px;"></i></a>
          </span>
        </section>
      </footer><br>
  </body>
</html>