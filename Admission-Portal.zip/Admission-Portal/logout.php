<?php
session_destroy();
header("location:admlogin.php");
?>