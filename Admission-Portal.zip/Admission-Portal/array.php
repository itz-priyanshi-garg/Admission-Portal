<?php
session_start();

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "admission_portal";

$con = new mysqli($hostname, $username, $password, $dbname);

$sq = "select * from admin";
$ro = $con->query($sq);

$i=0;

if($ro->num_rows)
{
while($row = $ro->fetch_array())
{
	$_SESSION['sdash'][$i]= array('Email'=>$row[1]);
	$i = $i + 1;
}
header("location:a_dash.php");
print_r($_SESSION['sdash']);
}
?>