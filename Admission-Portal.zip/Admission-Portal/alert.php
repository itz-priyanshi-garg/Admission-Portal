<html>
<head>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<script>

function show()
{
	document.getElementById("divexample").style.visibility="visible";
}

setTimeout("show()",1000);
function hide()
{
	document.getElementById("divexample").style.visibility="hidden";
}

setTimeout("hide()",2000);

</script>
</head>

<body>
	<center>
		<div id="divexample" style="visibility:hidden; height:40px; width:250px; background-color:#00cc00;"><h3 style="color:white"><i class='far fa-calendar-check' style='font-size:36px'></i>&nbsp; Status Updated</h3>
		</div>
	</center>
</body>
</html>